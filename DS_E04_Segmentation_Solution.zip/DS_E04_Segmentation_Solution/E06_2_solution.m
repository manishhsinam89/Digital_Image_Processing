clear all; close all;


%% ---------------------------Region Growing-------------------------------
%------ load image and transform it into duble - class ------
I = imread('coins.png');
figure; imshow(I);
I = round(255.*im2double(I));

%----- set gray-value tolerance -----
Tol = 70;

%----- set seed point -----
Seed = false(size(I));
Seed(48,183) = 1;
GVS = I(Seed);

%----- initialze segment-image -----
IS = false(size(I));
IS(Seed) = 1;

%----- Add Border Pixels to actual region in IS that fullfill tol-criteria
Border = ( imdilate(IS, ones(3)) - IS) == 1;
Border(Border) = abs(I(Border) - GVS) <= Tol;

while ~all(Border(:) == 0)
    
    IS =  IS | Border;
    
    Border = ( imdilate(IS, ones(3)) - IS) == 1;
    Border(Border) = abs(I(Border) - GVS) <= Tol;
    
end

%----- fill gaps via closing -----
IS = imclose(IS, ones(3));

%----- show extracted segment ------
figure; imshow(IS);
