clear all; close all;

%% -----------------------Pixel-based Segmentation-------------------------
%----- load and show picture -----
I = imread('seeds.tif');
figure; imshow(I);

%----- show histogram -----
figure; imhist(I);

%----- apply gray-value threshold -----
I2 = false(size(I));
SG = 110; % 150 % 185
I2(I < SG) = 1;
figure; imshow(I2);

%----- apply Otsu's threshold -----
level = graythresh(I);
SG = level .* 255;
I2(I < SG) = 1;
% I2 = im2bw(I,level); I2 = 1 - I2;
figure; imshow(I2);

