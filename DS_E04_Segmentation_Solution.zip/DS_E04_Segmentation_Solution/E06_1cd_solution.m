clear all; close all;


%% ----------------Pixel-based Segmentation with shading correction--------
%----- load and show spot shaded text image -----
I = imread('spot_shaded_text.tif');
figure; imshow(I);

%----- apply Otsu's threshold to reconstructed image -----
level = graythresh(I);
I1 = im2bw(I, level);
figure; imshow(I1);

%----- reconstruct shading image via median-filter -----
I2 = medfilt2(I, [25 25]);
figure; imshow(I2, []);

%----- correct multiplicative shading -----
It = im2double(I);
It2 = im2double(I2);
It2(It2 < 0.2) = 0.2; % 0.1
IR = It ./ It2;
IR = IR - min(IR(:)); IR = uint8( round( IR ./ max(IR(:)) .* 255 ));

figure; imshow(IR);

%----- apply Otsu's threshold to reconstructed image -----
level = graythresh(IR);
I4 = im2bw(IR, level);
figure; imshow(I4);
