clear all; close all;

%% 1b)
% define image and erosion mask
I = false(7, 7); I(2,3:5)=1; I(3:5,3:6)=1; I(4,2)=1; I(6,4)=1;

% perform erosion

%% 1c)
% define dilation mask

% perform dilation
