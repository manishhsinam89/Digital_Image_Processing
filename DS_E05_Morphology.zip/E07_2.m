clear all; close all;

% read image
I = imread('holes.tif');
figure; imshow(I);

% perform dilatation 

% perform erosion